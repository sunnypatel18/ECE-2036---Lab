// skeleton code for ECE 2036 thermostat lab
// code must be added by students
#include "mbed.h"
#include "TMP36.h"
#include "SDFileSystem.h"
#include "uLCD_4DGL.h"
#include "PinDetect.h"
#include "Speaker.h"
// must add your new class code to the project file Shiftbrite.h
#include "Shiftbrite.h"

// use class to setup temperature sensor pins
TMP36 myTMP36(p15);  //Analog in

// use class to setup the  Color LCD
uLCD_4DGL uLCD(p28, p27, p29); // create a global uLCD object

// use class to setup pushbuttons pins
PinDetect pb1(p23);
PinDetect pb2(p24);
PinDetect pb3(p25);
PinDetect pb4(p26);

// use class to setup speaker pin
Speaker mySpeaker(p21); //PWM out

// use class to setup Shiftbrite pins
Shiftbrite myShiftbrite(p9, p10, p11, p12, p13);// ei li di n/c ci

// use class to setup Mbed's four on-board LEDs
DigitalOut myLED1(LED1);
DigitalOut myLED2(LED2);
DigitalOut myLED3(LED3);
DigitalOut myLED4(LED4);



//also setting any unused analog input pins to digital outputs reduces A/D noise a bit
//see http://mbed.org/users/chris/notebook/Getting-best-ADC-performance/
DigitalOut P16(p16);
DigitalOut P17(p17);
DigitalOut P18(p18);
DigitalOut P19(p19);
DigitalOut P20(p20);




// Global variables used in callbacks and main program
// C variables in interrupt routines should use volatile keyword
int button4=0; //changes from C to F
float tempC, tempF;
int volatile heat_setpointF = 75;//set to 75 degrees F
int volatile heat_setpointC = 24;//set to 24 degrees C
int volatile cool_setpointF = 70;
int volatile cool_setpointC = 21;
enum statemode {cool = 0, heat, off}; // create 3 modes
statemode type = off;
enum Statetype { Heat_off = 0, Heat_on, Cool_on, Cool_off, shutdown}; //create 5 states
Statetype state = Heat_off;
char* typestate = "OFF"; //start in off state
// Callback routine is interrupt activated by a debounced pb1 hit
void pb1_hit_callback (void)
{
    mySpeaker.PlayNote(100.0, 0.1, 1.0); // Speaker buzz
    switch (type) {//increments the degree
        case heat:
            heat_setpointC++;
            heat_setpointF++;
            break;
        case cool:
            cool_setpointC++;
            cool_setpointF++;
            break;
        case off:
            type = heat;
            typestate = "HEAT";
            break;
    }
}
// Callback routine is interrupt activated by a debounced pb2 hit
void pb2_hit_callback (void)
{
    mySpeaker.PlayNote(200.0, 0.1, 1.0); // Speaker buzz
    switch (type) {//decrements the degree
        case heat:
            heat_setpointC--;
            heat_setpointF--;
            break;
        case cool:
            cool_setpointC--;
            cool_setpointF--;
            break;
        case off:
            type = cool;
            typestate = "COOL";
            break;
    }
}
// Callback routine is interrupt activated by a debounced pb3 hit
void pb3_hit_callback (void)
{
    mySpeaker.PlayNote(300.0, 0.1, 1.0); // Speaker buzz
    switch (type) {//cycles through the 3 modes
        case cool:
            type = heat;
            typestate = "HEAT";
            break;
        case heat:
            type = off;
            typestate = "OFF ";
            break;
        case off:
            type = cool;
            typestate = "COOL";
            break;
    }
}
// Callback routine is interrupt activated by a debounced pb4 hit
void pb4_hit_callback (void)
{
    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
    switch (type) {//changes from C to F or vice versa
        case off:
            type = heat;
            typestate = "HEAT";
    }
    if (button4 == 0) {
        button4 = 1;
    } else if (button4 == 1) {
        button4 = 0;
    }
}

int main()
{
    float Current_temp=0.0;

    // Use internal pullups for the three pushbuttons
    pb1.mode(PullUp);
    pb2.mode(PullUp);
    pb3.mode(PullUp);
    pb4.mode(PullUp);
    // Delay for initial pullup to take effect
    wait(.01);
    // Setup Interrupt callback functions for a pb hit
    pb1.attach_deasserted(&pb1_hit_callback);
    pb2.attach_deasserted(&pb2_hit_callback);
    pb3.attach_deasserted(&pb3_hit_callback);
    pb4.attach_deasserted(&pb4_hit_callback);
    // Start sampling pb inputs using interrupts
    pb1.setSampleFrequency();
    pb2.setSampleFrequency();
    pb3.setSampleFrequency();
    pb4.setSampleFrequency();
    // pushbuttons now setup and running


    // start I/O examples - DELETE THIS IN YOUR CODE..BUT WILL USE THESE I/O IDEAS ELSEWHERE
    // since all this compiles - the needed *.h files for these are in the project
    //
    Current_temp = myTMP36; //Read temp sensor
    mySpeaker.PlayNote(500.0, 1.0, 1.0); // Speaker buzz
    uLCD.baudrate(3000000);

    // State machine code below will need changes and additions
    while(1) {
        if (button4 == 0) {
            while(1) {
                Current_temp = myTMP36.read(); //reads temp from TMP36
                tempC = Current_temp;
                uLCD.color(WHITE);//extra credit
                uLCD.textbackground_color(GREEN);
                uLCD.set_font(FONT_7X8);
                uLCD.text_mode(OPAQUE);
                uLCD.text_height(2);
                uLCD.locate(0,0);
                uLCD.printf("Temp=%d C     %s\n",(int)tempC,typestate);//print current temp to lcd
                uLCD.triangle(120, 100, 40, 40, 10, 100, 0x0000FF);//create a triangle on the lcd
                uLCD.locate(5,5);
                uLCD.printf("Sunny");
                wait(0.25);
                switch (state) {   //switches between the states
                    case Heat_off: //case of the Heat_off
                        myLED1 = 1;
                        myLED2 = 0;
                        myLED3 = 0;
                        myLED4 = 0;
                        switch (type) {
                            case heat:
                                if (tempC < heat_setpointC) {
                                    state = Heat_on;
                                    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
                                } else if (tempC > heat_setpointC) {
                                    //prints the heat_off state
                                    uLCD.color(WHITE);
                                    uLCD.textbackground_color(RED);
                                    uLCD.set_font(FONT_7X8);
                                    uLCD.text_mode(OPAQUE);
                                    uLCD.locate(0,1);
                                    uLCD.printf("Holding above %d C\n",heat_setpointC);
                                    myShiftbrite.RGB(100,0,0);
                                }
                                break;
                            case cool:
                                if (tempC > cool_setpointC) {
                                    state = Cool_on;
                                } else if (tempC < cool_setpointC) {
                                    state = Cool_off;
                                }
                                break;
                            case off:
                                state = shutdown;
                                break;
                        }
                        break;
                    case Heat_on:
                        myLED1 = 1;
                        myLED2 = 0;
                        myLED3 = 1;
                        myLED4 = 0;
                        switch (type) {
                            case cool:
                                if (tempC < cool_setpointC) {
                                    state = Cool_off;
                                } else if (tempC > cool_setpointC) {
                                    state = Cool_on;
                                }
                                break;
                            case heat:
                                if (tempC > heat_setpointC) {
                                    state = Heat_off;
                                    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
                                } else if (tempC < heat_setpointC) {
                                    uLCD.color(WHITE);
                                    uLCD.textbackground_color(RED);
                                    uLCD.set_font(FONT_7X8);
                                    uLCD.text_mode(OPAQUE);
                                    uLCD.locate(0,1);
                                    uLCD.printf("Heating to %d C   \n",heat_setpointC);
                                    myShiftbrite.RGB(100,0,0);
                                }
                                break;
                            case off:
                                state = shutdown;
                                break;
                        }
                        break;
                    case Cool_on:
                        myLED1 = 0;
                        myLED2 = 1;
                        myLED3 = 0;
                        myLED4 = 1;
                        switch (type) {
                            case heat:
                                if (tempC < heat_setpointC) {
                                    state = Heat_on;
                                } else if (tempC > heat_setpointC) {
                                    state = Heat_off;
                                }
                                break;
                            case cool:
                                if (tempC < cool_setpointC) {
                                    state = Cool_off;
                                    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
                                } else if (tempC > cool_setpointC) {
                                    uLCD.color(WHITE);
                                    uLCD.textbackground_color(BLUE);
                                    uLCD.set_font(FONT_7X8);
                                    uLCD.text_mode(OPAQUE);
                                    uLCD.locate(0,1);
                                    uLCD.printf("Cooling to %d C   \n",cool_setpointC);
                                    myShiftbrite.RGB(0,0,100);
                                }
                                break;
                            case off:
                                state = shutdown;
                                break;
                        }
                        break;
                    case Cool_off:
                        myLED1 = 0;
                        myLED2 = 1;
                        myLED3 = 0;
                        myLED4 = 0;
                        switch (type) {
                            case heat:
                                if (tempC < heat_setpointC) {
                                    state = Heat_on;
                                } else if (tempC > heat_setpointC) {
                                    state = Heat_off;
                                }
                                break;
                            case cool:
                                if (tempC < cool_setpointC) {
                                    uLCD.color(WHITE);
                                    uLCD.textbackground_color(BLUE);
                                    uLCD.set_font(FONT_7X8);
                                    uLCD.text_mode(OPAQUE);
                                    uLCD.locate(0,1);
                                    uLCD.printf("Holding below %d C\n",cool_setpointC);
                                    myShiftbrite.RGB(0,0,100);
                                } else if (tempC > cool_setpointC) {
                                    state = Cool_on;
                                    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
                                }
                                break;
                            case off:
                                state = shutdown;
                                break;
                        }
                        break;
                    case shutdown:
                        myLED1 = 0;
                        myLED2 = 0;
                        myLED3 = 0;
                        myLED4 = 0;
                        switch (type) {
                            case off:
                                uLCD.textbackground_color(BLACK);
                                uLCD.locate(0,1);
                                uLCD.printf("                  ");
                                myShiftbrite.RGB(0,0,0);
                                break;
                            case heat:
                                if (tempC < heat_setpointC) {
                                    state = Heat_on;
                                } else if (tempC > heat_setpointC) {
                                    state = Heat_off;
                                }
                                break;
                            case cool:
                                if (tempC < cool_setpointC) {
                                    state = Cool_off;
                                } else if (tempC > cool_setpointC) {
                                    state = Cool_on;
                                }
                                break;
                        }
                        break;
                }
                break;
            }
        } else if (button4 == 1) { //same code but for the F
            while(1) {
                Current_temp = myTMP36.read();
                tempC = Current_temp;
                tempF = (9.0*tempC)/5.0 + 32.0;//convert from C to F
                uLCD.color(WHITE);
                uLCD.textbackground_color(GREEN);
                uLCD.set_font(FONT_7X8);
                uLCD.text_mode(OPAQUE);
                uLCD.locate(0,0);
                uLCD.text_height(2);
                uLCD.printf("Temp=%d F     %s\n",(int)tempF,typestate);
                uLCD.triangle(120, 100, 40, 40, 10, 100, 0x0000FF);
                uLCD.locate(5,5);
                uLCD.printf("Sunny");
                wait(0.25);
                switch (state) {
                    case Heat_off:
                        myLED1 = 1;
                        myLED2 = 0;
                        myLED3 = 0;
                        myLED4 = 0;
                        switch (type) {
                            case heat:
                                if (tempF < heat_setpointF) {
                                    state = Heat_on;
                                    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
                                } else if (tempF > heat_setpointF) {
                                    uLCD.color(WHITE);
                                    uLCD.textbackground_color(RED);
                                    uLCD.set_font(FONT_7X8);
                                    uLCD.text_mode(OPAQUE);
                                    uLCD.locate(0,1);
                                    uLCD.printf("Holding above %d F\n",heat_setpointF);
                                    myShiftbrite.RGB(100,0,0);
                                }
                                break;
                            case cool:
                                if (tempF > cool_setpointF) {
                                    state = Cool_on;
                                } else if (tempF < cool_setpointF) {
                                    state = Cool_off;
                                }
                                break;
                            case off:
                                state = shutdown;
                                break;
                        }
                        break;
                    case Heat_on:
                        myLED1 = 1;
                        myLED2 = 0;
                        myLED3 = 1;
                        myLED4 = 0;
                        switch (type) {
                            case cool:
                                if (tempF < cool_setpointF) {
                                    state = Cool_off;
                                } else if (tempF > cool_setpointF) {
                                    state = Cool_on;
                                }
                                break;
                            case heat:
                                if (tempF > heat_setpointF) {
                                    state = Heat_off;
                                    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
                                } else if (tempF < heat_setpointF) {
                                    uLCD.color(WHITE);
                                    uLCD.textbackground_color(RED);
                                    uLCD.set_font(FONT_7X8);
                                    uLCD.text_mode(OPAQUE);
                                    uLCD.locate(0,1);
                                    uLCD.printf("Heating to %d F   \n",heat_setpointF);
                                    myShiftbrite.RGB(100,0,0);
                                }
                                break;
                            case off:
                                state = shutdown;
                                break;
                        }
                        break;
                    case Cool_on:
                        myLED1 = 0;
                        myLED2 = 1;
                        myLED3 = 0;
                        myLED4 = 1;
                        switch (type) {
                            case heat:
                                if (tempF < heat_setpointF) {
                                    state = Heat_on;
                                } else if (tempF > heat_setpointF) {
                                    state = Heat_off;
                                }
                                break;
                            case cool:
                                if (tempF < cool_setpointF) {
                                    state = Cool_off;
                                    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
                                } else if (tempF > cool_setpointF) {
                                    uLCD.color(WHITE);
                                    uLCD.textbackground_color(BLUE);
                                    uLCD.set_font(FONT_7X8);
                                    uLCD.text_mode(OPAQUE);
                                    uLCD.locate(0,1);
                                    uLCD.printf("Cooling to %d F   \n",cool_setpointF);
                                    myShiftbrite.RGB(0,0,100);
                                }
                                break;
                            case off:
                                state = shutdown;
                                break;
                        }
                        break;
                    case Cool_off:
                        myLED1 = 0;
                        myLED2 = 1;
                        myLED3 = 0;
                        myLED4 = 0;
                        switch (type) {
                            case heat:
                                if (tempF < heat_setpointF) {
                                    state = Heat_on;
                                } else if (tempF > heat_setpointF) {
                                    state = Heat_off;
                                }
                                break;
                            case cool:
                                if (tempF < cool_setpointF) {
                                    uLCD.color(WHITE);
                                    uLCD.textbackground_color(BLUE);
                                    uLCD.set_font(FONT_7X8);
                                    uLCD.text_mode(OPAQUE);
                                    uLCD.locate(0,1);
                                    uLCD.printf("Holding below %d F\n",cool_setpointF);
                                    myShiftbrite.RGB(0,0,100);
                                } else if (tempF > cool_setpointF) {
                                    state = Cool_on;
                                    mySpeaker.PlayNote(400.0, 0.1, 1.0); // Speaker buzz
                                }
                                break;
                            case off:
                                state = shutdown;
                                break;
                        }
                        break;
                    case shutdown:
                        myLED1 = 0;
                        myLED2 = 0;
                        myLED3 = 0;
                        myLED4 = 0;
                        switch (type) {
                            case off:
                                uLCD.textbackground_color(BLACK);
                                uLCD.locate(0,1);
                                uLCD.printf("                  ");
                                myShiftbrite.RGB(0,0,0);
                            case heat:
                                if (tempF < heat_setpointF) {
                                    state = Heat_on;
                                } else if (tempF > heat_setpointF) {
                                    state = Heat_off;
                                }
                            case cool:
                                if (tempF < cool_setpointF) {
                                    state = Cool_off;
                                } else if (tempF > cool_setpointF) {
                                    state = Cool_on;
                                }
                                break;
                        }
                        break;
                }
                break;
            }
        }
    }
}