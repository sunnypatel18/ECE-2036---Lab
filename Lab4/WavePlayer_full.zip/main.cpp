#include "mbed.h"
#include "SDFileSystem.h"
#include "wave_player.h"
#include "PinDetect.h"
#include "uLCD_4DGL.h"
#include <vector>
#include <string>
#include "Speaker.h"

SDFileSystem sd(p5, p6, p7, p8, p9,"sd"); //SD card

// use class to setup the  Color LCD
uLCD_4DGL uLCD(p28, p27, p29); // create a global uLCD object

// use class to setup pushbuttons pins
PinDetect pb1(p23);
PinDetect pb2(p24);
PinDetect pb3(p25);
PinDetect pb4(p26);

// use class to setup Mbed's four on-board LEDs
DigitalOut myLED1(LED1);
DigitalOut myLED2(LED2);
DigitalOut myLED3(LED3);
DigitalOut myLED4(LED4);

AnalogOut DACout(p18);
DigitalOut P16(p16);
DigitalOut P17(p17);
DigitalOut P19(p19);
DigitalOut P20(p20);

bool playmode = 0;
int songnum = 0;
int volume = 0;
int count = 0;
bool checkSD = 0;
int play;
int mode;
int stop;
bool sdCheck;
wave_player waver(&DACout, &volume);

FILE *wave_file;
vector<string> filenames;

void pb1_hit_callback (void)
{
    if (playmode==0) {
        if (count==0) {
            count = songnum-2;
        } else {
            count=count-2;
        }

        uLCD.cls();
        uLCD.locate(0,0);
        uLCD.color(WHITE);
        for(int i=0; i<filenames.size(); i++) {
            string delims = filenames[i].c_str();

            if(delims[0]=='.') {
                continue;
            }
            delims=filenames[i].c_str();
            unsigned pos = delims.find(".wav");
            delims = delims.substr(0,pos);
            if(i==count) {
                uLCD.textbackground_color(RED);
                uLCD.printf("%s\n",delims.c_str());
            } else {
                uLCD.textbackground_color(OPAQUE);
                uLCD.printf("%s\n",delims.c_str());
            }
        }
    }
}

void pb2_hit_callback (void)
{
    if (playmode==0) {
        if (count==(songnum-2)) {
            count = 0;
        } else {
            count=count+2;
        }

        uLCD.cls();
        uLCD.locate(0,0);
        uLCD.color(WHITE);
        for(int i=0; i<filenames.size(); i++) {
            string delims = filenames[i].c_str();

            if(delims[0]=='.') {
                continue;
            }
            delims=filenames[i].c_str();
            unsigned pos = delims.find(".wav");
            delims = delims.substr(0,pos);
            if(i==count) {
                uLCD.textbackground_color(RED);
                uLCD.printf("%s\n",delims.c_str());
            } else {
                uLCD.textbackground_color(OPAQUE);
                uLCD.printf("%s\n",delims.c_str());
            }
        }
    }
}

void pb3_hit_callback (void)
{
    if(playmode==0) {
        playmode = 1;
    } else if (playmode == 1) {
        playmode = 0;
        uLCD.locate(0,5);
        uLCD.textbackground_color(OPAQUE);
        uLCD.printf("                ");
    }
}

void pb4_hit_callback (void)
{
    volume++;
    if (volume>=16) {
        volume=0;
    }
}

void read_file_names(char *dir)
{
    DIR *dp;
    struct dirent *dirp;
    dp = opendir(dir);
    while((dirp=readdir(dp)) != NULL) {
        filenames.push_back(string(dirp->d_name));
    }
}
int main()
{
    // Use internal pullups for the three pushbuttons
    pb1.mode(PullUp);
    pb2.mode(PullUp);
    pb3.mode(PullUp);
    pb4.mode(PullUp);
    // Delay for initial pullup to take effect
    wait(.01);
    // Setup Interrupt callback functions for a pb hit
    pb1.attach_deasserted(&pb1_hit_callback);
    pb2.attach_deasserted(&pb2_hit_callback);
    pb3.attach_deasserted(&pb3_hit_callback);
    pb4.attach_deasserted(&pb4_hit_callback);
    // Start sampling pb inputs using interrupts
    pb1.setSampleFrequency();
    pb2.setSampleFrequency();
    pb3.setSampleFrequency();
    pb4.setSampleFrequency();
    // pushbuttons now setup and running

    while(checkSD==0) {
        if(sd.SD_inserted()==1) {
            uLCD.cls();
            uLCD.printf("Insert SD Card");
            printf("Insert SD Card \n\n");
        } else if (sd.SD_inserted()==0) {
            uLCD.cls();
            sdCheck=1;
            uLCD.printf("SD Card Inserted\n\n");
            wait(1);
            uLCD.cls();
            break;
        }
    }

    read_file_names("/sd/myMusic");

    for(int i=0; i<filenames.size(); i++) {
        string delims = filenames[i].c_str();

        if(delims[0]=='.') {
            continue;
        }
        delims=filenames[i].c_str();
        unsigned pos = delims.find(".wav");
        delims = delims.substr(0,pos);
        uLCD.color(WHITE);
        uLCD.printf("%s\n",delims.c_str());
    }

    for(vector<string>::iterator it=filenames.begin(); it < filenames.end(); it++) {
        printf("%s\n\r",(*it).c_str());
        songnum++;
    }

    vector<string>::iterator it=filenames.begin();
    string filepath;
    filepath = "/sd/myMusic/";

    while (1) {
        if(playmode==1) {
            uLCD.locate(0,5);
            uLCD.color(WHITE);
            uLCD.textbackground_color(RED);
            uLCD.printf("Song Playing\n");
            string rem = filenames[count].c_str();
            unsigned pos = rem.find(".wav");
            rem = rem.substr(0,pos);
            wave_file=fopen((filepath + filenames[count]).c_str(), "r");
            waver.play(wave_file, &playmode);
            fclose(wave_file);
            playmode = 0;
        }
    }
}